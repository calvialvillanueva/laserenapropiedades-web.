import React from 'react';
import PropertyCard from '../components/PropertyCard';
import propiedades from '../data/propiedades_reales.json';
import './Home.css';

const Home = () => {
  return (
    <div className="page-home">
      {/* Hero Section */}
      <section className="hero-section" style={{ backgroundImage: `url('/images/hero_banner_la_serena_1777330592007.png')` }}>
        <div className="hero-overlay"></div>
        <div className="container hero-content animate-fade-in-up">
          <h1 className="title-xl text-white mb-2" style={{ textTransform: 'uppercase' }}>
            Encuentra tu Propiedad Ideal en <span className="text-gold" style={{ color: 'var(--secondary)' }}>La Serena</span>
          </h1>
          <p className="hero-subtitle mb-4">Arriendo y venta de departamentos y casas en Avenida del Mar, Serena Golf y La Herradura.</p>
          
          <div className="search-bar glass">
            <div className="search-inputs">
              <div className="search-group">
                <label>Operación</label>
                <select>
                  <option>Todos</option>
                  <option>Arriendo</option>
                  <option>Venta</option>
                  <option>Arriendo Verano</option>
                </select>
              </div>
              <div className="search-group">
                <label>Tipo</label>
                <select>
                  <option>Departamento</option>
                  <option>Casa</option>
                  <option>Parcela</option>
                </select>
              </div>
              <div className="search-group">
                <label>Sector</label>
                <select>
                  <option>Avenida del Mar</option>
                  <option>La Herradura</option>
                  <option>Serena Golf</option>
                </select>
              </div>
            </div>
            <button className="btn btn-secondary btn-search">Buscar Propiedades</button>
          </div>
        </div>
      </section>

      {/* Featured Properties */}
      <section className="section bg-light">
        <div className="container">
          <div className="section-header text-center mb-4">
            <h2 className="title-lg">Propiedades Destacadas</h2>
            <p className="text-muted">Explora nuestra selección de propiedades exclusivas en la IV Región.</p>
          </div>
          
          <div className="properties-grid">
            {propiedades.map(property => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
