import React from 'react';
import { Link } from 'react-router-dom';
import { Search, Menu } from 'lucide-react';
import './Header.css'; // Let's pretend we have this or just rely on index.css

const Header = () => {
  return (
    <header className="header glass">
      <div className="container header-container">
        <Link to="/" className="logo">
          <img src="/images/logo-horizontal.png" alt="La Serena Propiedades" height="65" />
        </Link>
        
        <nav className="desktop-nav">
          <ul className="nav-list">
            <li><Link to="/arriendo-la-serena" className="nav-link">Arriendos</Link></li>
            <li><Link to="/venta-propiedades-la-serena" className="nav-link">Ventas</Link></li>
            <li><Link to="/arriendo-verano-la-serena" className="nav-link highlight">Verano 2026</Link></li>
            <li><Link to="/blog" className="nav-link">Blog</Link></li>
          </ul>
        </nav>

        <div className="header-actions">
          <button className="btn btn-outline search-btn">
            <Search size={18} />
            <span>Buscar</span>
          </button>
          <button className="mobile-menu-btn">
            <Menu size={24} />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
