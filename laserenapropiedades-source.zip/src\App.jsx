import React from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import PropertyDetail from './pages/PropertyDetail';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

function App() {
  return (
    <Router>
      <div className="app-container">
        <Header />
        <main className="main-content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/propiedad/:id" element={<PropertyDetail />} />
            {/* Rutas SEO Placeholder */}
            <Route path="/arriendo-la-serena" element={<div className="container section" style={{marginTop: '80px'}}><h2>Arriendos</h2></div>} />
            <Route path="/venta-propiedades-la-serena" element={<div className="container section" style={{marginTop: '80px'}}><h2>Ventas</h2></div>} />
            <Route path="/arriendo-verano-la-serena" element={<div className="container section" style={{marginTop: '80px'}}><h2>Arriendo Verano</h2></div>} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
